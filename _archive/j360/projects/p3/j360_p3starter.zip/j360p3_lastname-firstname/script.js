// Part 1
$("#btn1").click(function() {
    // Do stuff here - use the selector $("#part1") and the .toggle() method
    $("#part1").toggle(500);
});

// Part 2
$("changeMe").click(function() {
    // $(selector).css(property, value);
});

// Part 3

// Part 4

// Part 5