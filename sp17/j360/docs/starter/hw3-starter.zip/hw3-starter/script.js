// Make a variable to hold our color

// use .click() on your squares. Then store the background-color in a variable


function setup() {
  // Create a 400x400 canvas
  // Give it a gray background
  // initialize c with a black color
}
function draw() {
  // set fill color to c
  // Use an if() statement to draw an ellipse if the mouseIsPressed
}