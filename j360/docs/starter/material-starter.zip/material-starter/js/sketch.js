function setup() {
    createCanvas(400, 400);

}

function draw() {
    ellipse(200, 200, 50, 50);
}